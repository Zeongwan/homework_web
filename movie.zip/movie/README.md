overall page:
    background:background.png;
    text on page: 8pt;
    text:Verdana, Tahoma, other sans-serif font
    overall body:no margin or padding
    top:a banneer

banner:
    center:banner.png;
    behind:bannerbackground.png repeat horizontally across the entire page(as the background);
    image:50px tall;

center heading:
    movie name and year:24pt Tahama, Verdana, other sans-serif

main body:
    1. #width:800px;
    2. center positioned;
    3. If the page resizes horizontally, this 800px section should move itself dynamically so that it remains centered horizontally on the page;
    4. This overall section has a 4px graysolid border and should be sized large enough to contain all of its contents

  left:
    1. a 550px-wide left-central section that contains the overall rotten rating of 32% and the critics' reviews of the movie
    2. topped by a smaller section containing a large rotten image (rottenbig.png)
    3. the image rottenbackground.png repeats horizontally across the entire length of the section.
    4. image: 83px(2-3)
    5. text: "32%" 48pt red
             "88 reviews total" 8pt
    6. quote box:
      1. background:#E1D697
      2. border: grey 2pt thick
      3. padding: 8px
      4. icons of feeling:left of box, 5px from text
      5. reviews information: name publiction in italic
      6. reviewer icon: left of box under text, 5px from text, 3em vertical between reviews
      7. The columns each occupy 47% of the width of the overall left-center section of the page. There is a horizontal spacing of 2% between the columns and neighboring content.

  right:
    1. width:250px
    2. 10px of space between the edge of the section and the text of the list.
    3. text of overview: background: #A2B964, text: 8pt in Arial,
    4. section: Each term is bolded and has 1em of vertical separation between it and the element that precedes it.
    5. bottom: link to http://www.tmnt.com/.

  bottom:
   Below the set of reviews is a bar with centered text explaining that the page shows reviews 1-8 of 88. This bar has a background color of #A2B964 and is placed directly up against its surrounding content. 5px separate the edge of its text and the element's own outer edge.

   The bottom right corner of the page has a section containing two links to the W3C validators. These are the same images and links as used in the previous assignment, with no borders. The W3C images are always present at the page's very bottom-right corner, both when the page first appears and after any scrolling.
